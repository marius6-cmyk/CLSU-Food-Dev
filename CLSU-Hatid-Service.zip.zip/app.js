// CLSU Hatid Service Application JavaScript

// Application State
let currentUser = null;
let users = [];
let orders = [];
let availableRequests = [];

// Application Data
const appData = {
  university_info: {
    name: "Central Luzon State University",
    abbreviation: "CLSU",
    colors: {
      primary: "#1B5E20",
      secondary: "#4CAF50",
      accent: "#FFC107",
      background: "#F5F5F5"
    }
  },
  campus_locations: [
    "Administration Building",
    "Library",
    "College of Engineering",
    "College of Business",
    "College of Agriculture",
    "College of Education",
    "Student Center",
    "Dormitory A",
    "Dormitory B",
    "Cafeteria",
    "Gymnasium",
    "Medical Clinic",
    "Faculty Center",
    "Graduate School",
    "Extension Office"
  ],
  departments: [
    "College of Agriculture",
    "College of Engineering",
    "College of Business Administration",
    "College of Education",
    "College of Arts and Sciences",
    "College of Veterinary Science and Medicine",
    "Graduate School",
    "Administration",
    "Extension Services"
  ],
  service_types: [
    "Document Delivery",
    "Package Delivery",
    "Food Delivery",
    "Emergency Delivery",
    "Academic Materials"
  ],
  sample_users: [
    {
      id: "2021-001",
      name: "Maria Santos",
      role: "Student",
      department: "College of Engineering",
      email: "maria.santos@clsu.edu.ph",
      phone: "09123456789",
      password: "password123"
    },
    {
      id: "2021-002",
      name: "Juan Dela Cruz",
      role: "Student",
      department: "College of Business Administration",
      email: "juan.delacruz@clsu.edu.ph",
      phone: "09234567890",
      password: "password123"
    },
    {
      id: "DR-001",
      name: "Roberto Garcia",
      role: "Driver",
      department: "Transportation Services",
      email: "roberto.garcia@clsu.edu.ph",
      phone: "09345678901",
      password: "driver123"
    }
  ],
  sample_orders: [
    {
      id: "ORD-001",
      customer: "Maria Santos",
      customerId: "2021-001",
      service_type: "Document Delivery",
      pickup_location: "College of Engineering",
      pickup_room: "Room 201",
      pickup_contact: "Maria Santos",
      pickup_phone: "09123456789",
      delivery_location: "Administration Building",
      delivery_room: "Room 105",
      recipient_name: "Dr. Jose Cruz",
      recipient_phone: "09111222333",
      package_description: "Academic transcripts",
      special_instructions: "Handle with care",
      urgency: "Normal",
      status: "In Transit",
      driver: "Roberto Garcia",
      driverId: "DR-001",
      timestamp: "2025-09-30T14:30:00",
      preferred_time: "2025-09-30T16:00:00"
    },
    {
      id: "ORD-002",
      customer: "Juan Dela Cruz",
      customerId: "2021-002",
      service_type: "Package Delivery",
      pickup_location: "Student Center",
      pickup_room: "Bookstore",
      pickup_contact: "Store Manager",
      pickup_phone: "09555666777",
      delivery_location: "Dormitory A",
      delivery_room: "Room 312",
      recipient_name: "Juan Dela Cruz",
      recipient_phone: "09234567890",
      package_description: "Textbooks and supplies",
      special_instructions: "",
      urgency: "Normal",
      status: "Delivered",
      driver: "Roberto Garcia",
      driverId: "DR-001",
      timestamp: "2025-09-30T10:15:00",
      preferred_time: "2025-09-30T12:00:00"
    }
  ]
};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
  setupEventListeners();
});

function initializeApp() {
  // Initialize sample data
  users = [...appData.sample_users];
  orders = [...appData.sample_orders];
  
  // Populate dropdowns
  populateDropdowns();
  
  // Check if user is logged in (simulate session)
  // For demo purposes, we'll start on landing page
  showPage('landing-page');
}

function populateDropdowns() {
  // Populate departments
  const departmentSelect = document.getElementById('register-department');
  if (departmentSelect) {
    departmentSelect.innerHTML = '<option value="">Select Department</option>';
    appData.departments.forEach(dept => {
      const option = document.createElement('option');
      option.value = dept;
      option.textContent = dept;
      departmentSelect.appendChild(option);
    });
  }

  // Populate service types
  const serviceTypeSelect = document.getElementById('service-type');
  if (serviceTypeSelect) {
    serviceTypeSelect.innerHTML = '<option value="">Select Service Type</option>';
    appData.service_types.forEach(service => {
      const option = document.createElement('option');
      option.value = service;
      option.textContent = service;
      serviceTypeSelect.appendChild(option);
    });
  }

  // Populate locations
  const pickupSelect = document.getElementById('pickup-location');
  const deliverySelect = document.getElementById('delivery-location');
  
  if (pickupSelect) {
    pickupSelect.innerHTML = '<option value="">Select Pickup Location</option>';
    appData.campus_locations.forEach(location => {
      const option = document.createElement('option');
      option.value = location;
      option.textContent = location;
      pickupSelect.appendChild(option);
    });
  }

  if (deliverySelect) {
    deliverySelect.innerHTML = '<option value="">Select Delivery Location</option>';
    appData.campus_locations.forEach(location => {
      const option = document.createElement('option');
      option.value = location;
      option.textContent = location;
      deliverySelect.appendChild(option);
    });
  }
}

function setupEventListeners() {
  // Login form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }

  // Register form
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegister);
  }

  // Delivery form
  const deliveryForm = document.getElementById('delivery-form');
  if (deliveryForm) {
    deliveryForm.addEventListener('submit', handleDeliveryRequest);
  }

  // Profile form
  const profileForm = document.getElementById('profile-form');
  if (profileForm) {
    profileForm.addEventListener('submit', handleProfileUpdate);
  }
}

// Page Navigation
function showPage(pageId) {
  // Hide all pages
  const pages = document.querySelectorAll('.page');
  pages.forEach(page => page.classList.remove('active'));

  // Show selected page
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.add('active');
  }

  // Update page-specific content
  if (pageId === 'dashboard-page') {
    loadDashboard();
  } else if (pageId === 'driver-dashboard-page') {
    loadDriverDashboard();
  }
}

// Authentication
function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  // Find user
  const user = users.find(u => u.email === email && u.password === password);
  
  if (user) {
    currentUser = user;
    showMessage('Login successful!', 'success');
    
    // Redirect based on role
    if (user.role === 'Driver') {
      showPage('driver-dashboard-page');
    } else {
      showPage('dashboard-page');
    }
  } else {
    showMessage('Invalid email or password', 'error');
  }
}

function handleRegister(e) {
  e.preventDefault();
  
  const formData = {
    name: document.getElementById('register-name').value,
    id: document.getElementById('register-id').value,
    email: document.getElementById('register-email').value,
    phone: document.getElementById('register-phone').value,
    role: document.getElementById('register-role').value,
    department: document.getElementById('register-department').value,
    password: document.getElementById('register-password').value,
    confirmPassword: document.getElementById('register-confirm-password').value
  };

  // Validation
  if (formData.password !== formData.confirmPassword) {
    showMessage('Passwords do not match', 'error');
    return;
  }

  if (users.find(u => u.email === formData.email)) {
    showMessage('Email already registered', 'error');
    return;
  }

  if (users.find(u => u.id === formData.id)) {
    showMessage('ID number already registered', 'error');
    return;
  }

  // Create new user
  const newUser = {
    id: formData.id,
    name: formData.name,
    role: formData.role,
    department: formData.department,
    email: formData.email,
    phone: formData.phone,
    password: formData.password
  };

  users.push(newUser);
  showMessage('Registration successful! Please login.', 'success');
  showPage('login-page');
}

function logout() {
  currentUser = null;
  showPage('landing-page');
  showMessage('Logged out successfully', 'success');
}

// Dashboard Functions
function loadDashboard() {
  if (!currentUser) {
    showPage('landing-page');
    return;
  }

  // Update user name
  const userNameElement = document.getElementById('user-name');
  if (userNameElement) {
    userNameElement.textContent = currentUser.name;
  }

  // Update stats
  updateDashboardStats();
  
  // Load recent orders
  loadRecentOrders();
  
  // Load profile data
  loadProfileData();
  
  // Load all orders
  loadUserOrders();
}

function updateDashboardStats() {
  const userOrders = orders.filter(order => order.customerId === currentUser.id);
  
  document.getElementById('total-orders').textContent = userOrders.length;
  document.getElementById('pending-orders').textContent = 
    userOrders.filter(order => ['Pending', 'Confirmed', 'Picked up', 'In Transit'].includes(order.status)).length;
  document.getElementById('completed-orders').textContent = 
    userOrders.filter(order => order.status === 'Delivered').length;
}

function loadRecentOrders() {
  const userOrders = orders
    .filter(order => order.customerId === currentUser.id)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 3);

  const recentOrdersList = document.getElementById('recent-orders-list');
  if (!recentOrdersList) return;

  if (userOrders.length === 0) {
    recentOrdersList.innerHTML = '<p class="no-orders">No recent orders found.</p>';
    return;
  }

  recentOrdersList.innerHTML = userOrders.map(order => `
    <div class="order-item">
      <div class="order-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</div>
      </div>
      <div class="order-info">
        <div class="info-item">
          <div class="info-label">Service Type</div>
          <div class="info-value">${order.service_type}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${formatDate(order.timestamp)}</div>
        </div>
      </div>
    </div>
  `).join('');
}

function loadProfileData() {
  if (!currentUser) return;

  document.getElementById('profile-name').value = currentUser.name;
  document.getElementById('profile-id').value = currentUser.id;
  document.getElementById('profile-email').value = currentUser.email;
  document.getElementById('profile-phone').value = currentUser.phone;
  document.getElementById('profile-role').value = currentUser.role;
  document.getElementById('profile-department').value = currentUser.department;
}

// Dashboard Section Navigation
function showDashboardSection(sectionId) {
  // Update nav buttons
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');

  // Hide all sections
  const sections = document.querySelectorAll('.dashboard-section');
  sections.forEach(section => section.classList.remove('active'));

  // Show selected section
  const targetSection = document.getElementById(sectionId + '-section');
  if (targetSection) {
    targetSection.classList.add('active');
  }

  // Load section-specific data
  if (sectionId === 'orders') {
    loadUserOrders();
  }
}

// Order Management
function handleDeliveryRequest(e) {
  e.preventDefault();

  const formData = {
    service_type: document.getElementById('service-type').value,
    urgency: document.getElementById('urgency').value,
    pickup_location: document.getElementById('pickup-location').value,
    pickup_room: document.getElementById('pickup-room').value,
    pickup_contact: document.getElementById('pickup-contact').value,
    pickup_phone: document.getElementById('pickup-phone').value,
    delivery_location: document.getElementById('delivery-location').value,
    delivery_room: document.getElementById('delivery-room').value,
    recipient_name: document.getElementById('recipient-name').value,
    recipient_phone: document.getElementById('recipient-phone').value,
    package_description: document.getElementById('package-description').value,
    special_instructions: document.getElementById('special-instructions').value,
    preferred_time: document.getElementById('preferred-time').value
  };

  // Create new order
  const newOrder = {
    id: 'ORD-' + String(orders.length + 1).padStart(3, '0'),
    customer: currentUser.name,
    customerId: currentUser.id,
    ...formData,
    status: 'Pending',
    driver: null,
    driverId: null,
    timestamp: new Date().toISOString()
  };

  orders.push(newOrder);
  availableRequests.push(newOrder);

  showMessage('Delivery request submitted successfully!', 'success');
  resetDeliveryForm();
  showDashboardSection('orders');
  updateDashboardStats();
}

function resetDeliveryForm() {
  document.getElementById('delivery-form').reset();
}

function loadUserOrders() {
  const userOrders = orders
    .filter(order => order.customerId === currentUser.id)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const ordersList = document.getElementById('orders-list');
  if (!ordersList) return;

  if (userOrders.length === 0) {
    ordersList.innerHTML = '<p class="no-orders">No orders found.</p>';
    return;
  }

  ordersList.innerHTML = userOrders.map(order => `
    <div class="order-item">
      <div class="order-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</div>
      </div>
      <div class="order-info">
        <div class="info-item">
          <div class="info-label">Service Type</div>
          <div class="info-value">${order.service_type}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location} - ${order.pickup_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location} - ${order.delivery_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Recipient</div>
          <div class="info-value">${order.recipient_name}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${formatDate(order.timestamp)}</div>
        </div>
        ${order.driver ? `
        <div class="info-item">
          <div class="info-label">Driver</div>
          <div class="info-value">${order.driver}</div>
        </div>
        ` : ''}
      </div>
      <div class="order-actions">
        <button class="btn btn--outline btn--sm" onclick="viewOrderDetails('${order.id}')">View Details</button>
        ${order.status === 'Pending' ? `<button class="btn btn--secondary btn--sm" onclick="cancelOrder('${order.id}')">Cancel</button>` : ''}
      </div>
    </div>
  `).join('');
}

function filterOrders() {
  const statusFilter = document.getElementById('status-filter').value;
  let filteredOrders = orders.filter(order => order.customerId === currentUser.id);

  if (statusFilter) {
    filteredOrders = filteredOrders.filter(order => order.status === statusFilter);
  }

  // Re-render orders list with filtered data
  const ordersList = document.getElementById('orders-list');
  if (filteredOrders.length === 0) {
    ordersList.innerHTML = '<p class="no-orders">No orders match the selected filter.</p>';
    return;
  }

  // Use the same rendering logic as loadUserOrders but with filtered data
  ordersList.innerHTML = filteredOrders.map(order => `
    <div class="order-item">
      <div class="order-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</div>
      </div>
      <div class="order-info">
        <div class="info-item">
          <div class="info-label">Service Type</div>
          <div class="info-value">${order.service_type}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location} - ${order.pickup_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location} - ${order.delivery_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Recipient</div>
          <div class="info-value">${order.recipient_name}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Date</div>
          <div class="info-value">${formatDate(order.timestamp)}</div>
        </div>
        ${order.driver ? `
        <div class="info-item">
          <div class="info-label">Driver</div>
          <div class="info-value">${order.driver}</div>
        </div>
        ` : ''}
      </div>
      <div class="order-actions">
        <button class="btn btn--outline btn--sm" onclick="viewOrderDetails('${order.id}')">View Details</button>
        ${order.status === 'Pending' ? `<button class="btn btn--secondary btn--sm" onclick="cancelOrder('${order.id}')">Cancel</button>` : ''}
      </div>
    </div>
  `).join('');
}

function viewOrderDetails(orderId) {
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  const modalContent = `
    <div class="order-details">
      <div class="detail-section">
        <h4>Order Information</h4>
        <p><strong>Order ID:</strong> ${order.id}</p>
        <p><strong>Service Type:</strong> ${order.service_type}</p>
        <p><strong>Status:</strong> <span class="status-badge status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</span></p>
        <p><strong>Urgency:</strong> ${order.urgency}</p>
        <p><strong>Order Date:</strong> ${formatDate(order.timestamp)}</p>
        ${order.preferred_time ? `<p><strong>Preferred Time:</strong> ${formatDate(order.preferred_time)}</p>` : ''}
      </div>
      
      <div class="detail-section">
        <h4>Pickup Details</h4>
        <p><strong>Location:</strong> ${order.pickup_location}</p>
        <p><strong>Room:</strong> ${order.pickup_room}</p>
        <p><strong>Contact:</strong> ${order.pickup_contact}</p>
        <p><strong>Phone:</strong> ${order.pickup_phone}</p>
      </div>
      
      <div class="detail-section">
        <h4>Delivery Details</h4>
        <p><strong>Location:</strong> ${order.delivery_location}</p>
        <p><strong>Room:</strong> ${order.delivery_room}</p>
        <p><strong>Recipient:</strong> ${order.recipient_name}</p>
        <p><strong>Phone:</strong> ${order.recipient_phone}</p>
      </div>
      
      <div class="detail-section">
        <h4>Package Information</h4>
        <p><strong>Description:</strong> ${order.package_description}</p>
        ${order.special_instructions ? `<p><strong>Special Instructions:</strong> ${order.special_instructions}</p>` : ''}
      </div>
      
      ${order.driver ? `
      <div class="detail-section">
        <h4>Driver Information</h4>
        <p><strong>Driver:</strong> ${order.driver}</p>
        <p><strong>Status:</strong> ${order.status}</p>
      </div>
      ` : ''}
    </div>
  `;

  document.getElementById('order-details-content').innerHTML = modalContent;
  showModal('order-modal');
}

function cancelOrder(orderId) {
  if (confirm('Are you sure you want to cancel this order?')) {
    const orderIndex = orders.findIndex(o => o.id === orderId);
    if (orderIndex !== -1) {
      orders[orderIndex].status = 'Cancelled';
      showMessage('Order cancelled successfully', 'success');
      loadUserOrders();
      updateDashboardStats();
    }
  }
}

// Driver Dashboard
function loadDriverDashboard() {
  if (!currentUser || currentUser.role !== 'Driver') {
    showPage('landing-page');
    return;
  }

  loadAvailableRequests();
  loadActiveDeliveries();
  loadCompletedDeliveries();
}

function showDriverSection(sectionId) {
  // Update nav buttons
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');

  // Hide all sections
  const sections = document.querySelectorAll('.dashboard-section');
  sections.forEach(section => section.classList.remove('active'));

  // Show selected section
  const targetSection = document.getElementById(sectionId + '-section');
  if (targetSection) {
    targetSection.classList.add('active');
  }
}

function loadAvailableRequests() {
  const availableOrders = orders.filter(order => order.status === 'Pending');
  const container = document.getElementById('available-requests');
  
  if (!container) return;

  if (availableOrders.length === 0) {
    container.innerHTML = '<p class="no-orders">No available requests at the moment.</p>';
    return;
  }

  container.innerHTML = availableOrders.map(order => `
    <div class="request-item">
      <div class="request-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-pending">Pending</div>
      </div>
      <div class="request-info">
        <div class="info-item">
          <div class="info-label">Customer</div>
          <div class="info-value">${order.customer}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Service Type</div>
          <div class="info-value">${order.service_type}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Urgency</div>
          <div class="info-value">${order.urgency}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Package</div>
          <div class="info-value">${order.package_description}</div>
        </div>
      </div>
      <div class="request-actions">
        <button class="btn btn--primary btn--sm" onclick="acceptRequest('${order.id}')">Accept</button>
        <button class="btn btn--outline btn--sm" onclick="viewOrderDetails('${order.id}')">View Details</button>
      </div>
    </div>
  `).join('');
}

function loadActiveDeliveries() {
  const activeOrders = orders.filter(order => 
    order.driverId === currentUser.id && 
    ['Confirmed', 'Picked up', 'In Transit'].includes(order.status)
  );
  
  const container = document.getElementById('active-deliveries');
  if (!container) return;

  if (activeOrders.length === 0) {
    container.innerHTML = '<p class="no-orders">No active deliveries.</p>';
    return;
  }

  container.innerHTML = activeOrders.map(order => `
    <div class="request-item">
      <div class="request-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-${order.status.toLowerCase().replace(' ', '-')}">${order.status}</div>
      </div>
      <div class="request-info">
        <div class="info-item">
          <div class="info-label">Customer</div>
          <div class="info-value">${order.customer}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location} - ${order.pickup_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location} - ${order.delivery_room}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Package</div>
          <div class="info-value">${order.package_description}</div>
        </div>
      </div>
      <div class="request-actions">
        ${getStatusUpdateButtons(order)}
        <button class="btn btn--outline btn--sm" onclick="viewOrderDetails('${order.id}')">View Details</button>
      </div>
    </div>
  `).join('');
}

function loadCompletedDeliveries() {
  const completedOrders = orders.filter(order => 
    order.driverId === currentUser.id && order.status === 'Delivered'
  );
  
  const container = document.getElementById('completed-deliveries');
  if (!container) return;

  if (completedOrders.length === 0) {
    container.innerHTML = '<p class="no-orders">No completed deliveries.</p>';
    return;
  }

  container.innerHTML = completedOrders.map(order => `
    <div class="request-item">
      <div class="request-header">
        <div class="order-id">${order.id}</div>
        <div class="status-badge status-delivered">Delivered</div>
      </div>
      <div class="request-info">
        <div class="info-item">
          <div class="info-label">Customer</div>
          <div class="info-value">${order.customer}</div>
        </div>
        <div class="info-item">
          <div class="info-label">From</div>
          <div class="info-value">${order.pickup_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">To</div>
          <div class="info-value">${order.delivery_location}</div>
        </div>
        <div class="info-item">
          <div class="info-label">Delivered</div>
          <div class="info-value">${formatDate(order.timestamp)}</div>
        </div>
      </div>
    </div>
  `).join('');
}

function acceptRequest(orderId) {
  const orderIndex = orders.findIndex(o => o.id === orderId);
  if (orderIndex !== -1) {
    orders[orderIndex].status = 'Confirmed';
    orders[orderIndex].driver = currentUser.name;
    orders[orderIndex].driverId = currentUser.id;
    
    showMessage('Request accepted successfully!', 'success');
    loadAvailableRequests();
    loadActiveDeliveries();
  }
}

function getStatusUpdateButtons(order) {
  switch (order.status) {
    case 'Confirmed':
      return `<button class="btn btn--primary btn--sm" onclick="updateOrderStatus('${order.id}', 'Picked up')">Mark as Picked Up</button>`;
    case 'Picked up':
      return `<button class="btn btn--primary btn--sm" onclick="updateOrderStatus('${order.id}', 'In Transit')">Mark as In Transit</button>`;
    case 'In Transit':
      return `<button class="btn btn--primary btn--sm" onclick="updateOrderStatus('${order.id}', 'Delivered')">Mark as Delivered</button>`;
    default:
      return '';
  }
}

function updateOrderStatus(orderId, newStatus) {
  const orderIndex = orders.findIndex(o => o.id === orderId);
  if (orderIndex !== -1) {
    orders[orderIndex].status = newStatus;
    showMessage(`Order status updated to ${newStatus}`, 'success');
    loadActiveDeliveries();
    loadCompletedDeliveries();
  }
}

// Profile Management
function handleProfileUpdate(e) {
  e.preventDefault();
  
  const updatedData = {
    name: document.getElementById('profile-name').value,
    email: document.getElementById('profile-email').value,
    phone: document.getElementById('profile-phone').value
  };

  // Update current user
  Object.assign(currentUser, updatedData);
  
  // Update in users array
  const userIndex = users.findIndex(u => u.id === currentUser.id);
  if (userIndex !== -1) {
    Object.assign(users[userIndex], updatedData);
  }

  showMessage('Profile updated successfully!', 'success');
}

// Utility Functions
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function showMessage(message, type = 'success') {
  const messageContainer = document.getElementById('message-container');
  const messageElement = document.getElementById('message');
  
  if (messageContainer && messageElement) {
    messageElement.textContent = message;
    messageElement.className = `message ${type}`;
    messageContainer.classList.remove('hidden');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      messageContainer.classList.add('hidden');
    }, 5000);
  }
}

function showModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('hidden');
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('hidden');
  }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal')) {
    e.target.classList.add('hidden');
  }
});

// Demo functions for easy testing
function loginAsStudent() {
  document.getElementById('login-email').value = 'maria.santos@clsu.edu.ph';
  document.getElementById('login-password').value = 'password123';
  document.getElementById('login-form').dispatchEvent(new Event('submit'));
}

function loginAsDriver() {
  document.getElementById('login-email').value = 'roberto.garcia@clsu.edu.ph';
  document.getElementById('login-password').value = 'driver123';
  document.getElementById('login-form').dispatchEvent(new Event('submit'));
}

// Add some demo buttons (for testing purposes)
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
  document.addEventListener('DOMContentLoaded', function() {
    // Add demo login buttons for testing
    const demoButtons = document.createElement('div');
    demoButtons.style.cssText = 'position: fixed; top: 10px; right: 10px; z-index: 9999; display: flex; gap: 5px;';
    demoButtons.innerHTML = `
      <button onclick="loginAsStudent()" style="padding: 5px 10px; font-size: 10px;">Demo Student</button>
      <button onclick="loginAsDriver()" style="padding: 5px 10px; font-size: 10px;">Demo Driver</button>
    `;
    document.body.appendChild(demoButtons);
  });
}